$(document).ready(function(){
    $('.admWrap').click(function(){
        $('.setenv_menu').hide();
    });
    $('.setenv').click(function(e){
        e.stopPropagation();
        $('.setenv_menu').toggle();
    });
	navMotion();
	$('.adm_menu').each(function(){
		var mainnav = $(this).find('h3');
		var subnav = mainnav.next('ul');
		if ( subnav.length ){
			mainnav.find('a').append('<span class="caret"></span>');
		}
    });
    
    var minWidth = 0;
    $('.adm_menu').each(function(index){
        minWidth += parseInt($(this).outerWidth());
        if ( minWidth > 1280 ){
            $('.admWrap, #admHeader').css('min-width', minWidth);
        }
    });
    
	function navMotion(){
		var navName = $('#admNav'),
			navCheck = $('.type_nav input'),
			navChecked = $('.type_nav input:checked').attr('id'),
			navTypeV = 'type_vertical',
      navTypeH = 'type_horizontal';
            
        if( navChecked == navTypeV ){
            navName.removeClass(navTypeH).addClass(navChecked);
        } if( navChecked == navTypeH ){
            navName.removeClass(navTypeV).addClass(navChecked);
        }

		$('.adm_menu').each(function(){
			var h3_wd = $(this).find('h3').outerWidth();
			if( navName.hasClass(navTypeV) ){
				$(this).find('.nav_dep1').css('width',h3_wd);
				$(this).find('ul.nav_dep1 > li').css({'width': 'auto'});
			} if( navName.hasClass(navTypeH) ){
				$(this).find('.nav_dep1').css('width','auto');
				$(this).find('ul.nav_dep1 > li').css({'width': $(document).width()/$(this).find('ul.nav_dep1 > li').length });
			}
		});
		
		navCheck.off().on('click', function(){
			navChecked = $(this).attr('id');
			navMotion();
		});

		$('.adm_menu').mouseenter(function(){
			if ( navName.hasClass(navTypeV) ){
				$('ul.nav_dep1').show();
			} if ( navName.hasClass(navTypeH) ) {
				$(this).find('ul.nav_dep1').show();
			}
		}).mouseleave(function(){
			$('ul.nav_dep1').hide();
		});
	}
	$(window).resize(function(){
		navMotion();
	});
	$(window).scroll(function(){
		var admHeader = $('#admHeader'),
			admWin_left = $(window).scrollLeft();

		admHeader.css({ 'left':-admWin_left })
	});

	$('.dropfixed').each(function(){
		var w_1 = $(this).find('.dropdown-toggle').outerWidth();
		var w_2 = $(this).find('.dropdown-menu').outerWidth();
		if ( w_1 < w_2 ){
			$(this).find('.dropdown-toggle').css({ 'width': w_2 });
		} else {
			$(this).find('.dropdown-menu').css({ 'width': w_1 });
		}
	});
  checkDs();

  if ( $('.nav-tabs-ls').length && !$('.nav-tabs-ls > li > a > span').length ){
    $('.nav-tabs-ls > li > a').each(function(){
      $(this).wrapInner('<span></span>');
    });
  }

  var secondNav = $('.secondNav');
  if ( secondNav.length ){
    secondNav.find('h3').each(function(){
      var _this = $(this);
      if ( !_this.next('ul').length ){
        _this.addClass('mn');
      } else {
        _this.find('a').click(function(e){
          if ( _this.hasClass('open') ){
            _this.removeClass('open');
          } else {
            _this.addClass('open');
          }
          e.preventDefault();
        });
      }
    });
    secondNav.find('.dep-2 > li').each(function(){
      var _this = $(this);
      if( !_this.find('a').next('ul').length ){
        _this.find('a').addClass('mn');
      } else {
        _this.find('a').click(function(e){
          if ( _this.hasClass('open') ){
            _this.removeClass('open');
          } else {
            _this.addClass('open');
          }
          e.preventDefault();
        });
      }
    });
  }
});

function checkDs(){
	$('.dsCheck').each(function(){
		if ( !$(this).find('.ds_input').length ){
			$(this).find('input[type="checkbox"], input[type="radio"]').after('<span class="ds_input"></span>');
		}
    });
}