// 'use strict';

const 
// pkg = require('./package.json'),
gulp = require('gulp'),
sass = require('gulp-sass'),
watch = require('gulp-watch'),
cached = require('gulp-cached'),
sourcemaps = require('gulp-sourcemaps'),
sassPartialsImported = require('gulp-sass-partials-imported'),
autoprefixer = require('gulp-autoprefixer');

const src = {
  // desktop: path.normalize(`${os.homedir()}/Desktop`),
  sassDir: './src/sass/',
  sassVendor: './src/sass/vendor',
  sass: './src/sass/**/*.scss',
  cssCompress: './dist/css/**/*',
  cssDist: './dist/css',
}

gulp.task('sass', () => {
	gulp.src(src.sass)
		.pipe(cached('sassfiles'))
      .pipe(sassPartialsImported(src.sassDir, src.sassVendor))
      .pipe(sourcemaps.init())
      .pipe(sass({
          outputStyle: 'compact', 
          includePaths: src.sassDir, 
      }).on('error', sass.logError))
      .pipe(autoprefixer())
      .pipe(sourcemaps.write('./'))
		.pipe(gulp.dest(src.cssDist))
});

gulp.task('watch:sass', () => {
    gulp.watch(src.sass, ['sass']);
});

gulp.task('build-min:sass', () => {
  return gulp.src(src.sass)
    .pipe(sass().on('error', sass.logError))
    .pipe(autoprefixer())
    .pipe(cleanCSS({
        compatibility: 'ie10'
    }))
    .pipe(gulp.dest(src.cssDist))
});

gulp.task('default', ['watch:sass']);